'''
    작성자: 정도현
    작성일: 2025.08.14
    파일명: practice9.py

    < 실습 내용 > 
    AI 기반 고객 리뷰 분석 시스템을 개발하는 팀의 일원
    고객 리뷰 문장을 벡터로 임베딩하고,
    PostgreSQL의 pgvector 기능을 활용하여 비슷한 리뷰를 검색하는 기능을 구현
'''

from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv
from psycopg2 import connect
import os

# .env 파일에서 환경 변수 로드
load_dotenv()

# PostgreSQL 연결 정보
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_NAME = os.getenv('DB_NAME', 'your_database')
DB_PASSWORD = os.getenv('DB_PASSWORD', 'your_password')

# PostgreSQL 연결
conn = connect(
    host=DB_HOST,
    database=DB_NAME,
    password=DB_PASSWORD
)
print(conn)

# 커서 생성
cur = conn.cursor()

# 1단계: 리뷰 데이터
reviews = [
    "배송이 빠르고 제품도 좋아요.",
    "품질이 기대 이상입니다!",
    "생각보다 배송이 오래 걸렸어요.",
    "배송은 느렸지만 포장은 안전했어요.",
    "아주 만족스러운 제품입니다."
]

# SentenceTransformer 모델 로드
model = SentenceTransformer('sentence-transformers/paraphrase-MiniLM-L6-v2')

# 리뷰 임베딩
embeddings = model.encode(reviews)

# 2단계: PostgreSQL 테이블 생성
cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
cur.execute("""
    CREATE TABLE IF NOT EXISTS review_vectors (
        id SERIAL PRIMARY KEY,
        review TEXT,
        embedding VECTOR(384) -- MiniLM 모델 기준 384차원
    );
""")
conn.commit()

# 3단계: 기존 데이터 초기화 후 저장
cur.execute("TRUNCATE review_vectors;")
for review, embedding in zip(reviews, embeddings):
    # 벡터를 PostgreSQL vector 리터럴 문자열로 변환
    embedding_str = "[" + ",".join(str(x) for x in embedding) + "]"
    cur.execute(
        "INSERT INTO review_vectors (review, embedding) VALUES (%s, %s::vector)",
        (review, embedding_str)
    )
conn.commit()

# 4단계: 유사도 검색
query_sentence = "배송이 느렸어요"
query_embedding = model.encode([query_sentence])[0].tolist()
query_embedding_str = "[" + ",".join(str(x) for x in query_embedding) + "]"

query = """
    SELECT review, embedding, (1 - (embedding <=> %s::vector)) AS similarity
    FROM review_vectors
    ORDER BY similarity DESC
    LIMIT 3;
"""

cur.execute(query, (query_embedding_str,))
results = cur.fetchall()

# 결과 출력
for review, embedding, similarity in results:
    print(f"유사도: {similarity:.4f}, 리뷰: {review}")

# 연결 종료
cur.close()
conn.close()
