package com.skala.springbootsample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpRequestJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpRequestJpaApplication.class, args);
	}
}
