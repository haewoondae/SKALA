package com.skala.springbootsample.dto;

import lombok.Data;

@Data
public class Team {
    private String position;
    private String detail;
}

