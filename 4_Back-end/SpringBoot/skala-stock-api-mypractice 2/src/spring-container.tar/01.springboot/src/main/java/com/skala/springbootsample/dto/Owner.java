package com.skala.springbootsample.dto;

import lombok.Data;

@Data
public class Owner {
    private String name;
    private String role;
    private String level;
}
